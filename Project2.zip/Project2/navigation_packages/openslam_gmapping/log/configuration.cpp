#include "gmapping/log/configuration.h"

namespace GMapping {

Configuration::~Configuration(){
}

};
