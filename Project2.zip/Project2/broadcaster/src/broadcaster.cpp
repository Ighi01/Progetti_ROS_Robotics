#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>


void broadcast_odometries(const nav_msgs::Odometry::ConstPtr& msg_odom){      

        static tf2_ros::TransformBroadcaster transform_broadcaster;
	geometry_msgs::TransformStamped transformStamped;

 	transformStamped.header.stamp = msg_odom->header.stamp;
        transformStamped.header.frame_id = "odom";
        transformStamped.child_frame_id = "base_footprint";
        transformStamped.transform.translation.x = msg_odom->pose.pose.position.x;
        transformStamped.transform.translation.y = msg_odom->pose.pose.position.y;
        transformStamped.transform.translation.z = msg_odom->pose.pose.position.z;
        transformStamped.transform.rotation.x = msg_odom->pose.pose.orientation.x;
        transformStamped.transform.rotation.y = msg_odom->pose.pose.orientation.y;
        transformStamped.transform.rotation.z = msg_odom->pose.pose.orientation.z;
        transformStamped.transform.rotation.w = msg_odom->pose.pose.orientation.w;
        transform_broadcaster.sendTransform(transformStamped);
}


int main(int argc, char **argv){
	ros::init(argc, argv, "broadcaster");
	ros::NodeHandle n;
	ros::Subscriber sub;

        sub = n.subscribe("/odom", 1000, broadcast_odometries);

        ros::spin();
	return 0;
}
